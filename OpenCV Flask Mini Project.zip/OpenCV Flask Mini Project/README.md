# OpenCV-with-Flask-Project-01---Mini-Project
OpenCV with Flask Server Project-01 - Mini Project
